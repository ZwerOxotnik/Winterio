data:extend({

  {
    type = "recipe-category",
    name = "snow-crafting"
  }
  
})